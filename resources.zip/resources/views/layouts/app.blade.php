<!DOCTYPE html>
<html>
<head>
    <title>@yield('title', 'SAFILII BUS')</title>
</head>
<body>
    @yield('content')
</body>
</html>
